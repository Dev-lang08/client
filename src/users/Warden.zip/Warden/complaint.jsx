import React from 'react'

const WardenComplaint = () => {
    return (
        <div>WardenComplaint</div>
    )
}

export default WardenComplaint;