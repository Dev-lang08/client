import React, { useState, useEffect } from 'react';

const App = () => {
    const [studentData, setStudentData] = useState(null);
    const [wardenName, setWardenName] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        fetchStudentData();
        fetchWardenName();
    }, []);

    const fetchStudentData = async () => {
        try {
            const response = await fetch('http://localhost:8000/api/v1/student/me/');
            const data = await response.json();
            setStudentData(data);
        } catch (error) {
            console.error('Error fetching student data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchWardenName = async () => {
        try {
            const response = await fetch('http://localhost:8000/api/v1/student/me/my-warden');
            const data = await response.json();
            setWardenName(data.name);
        } catch (error) {
            console.error('Error fetching warden name:', error);
        }
    };

    return (
        <div>
            <h1>Student Information</h1>
            {isLoading ? (
                <p>Loading...</p>
            ) : studentData ? (
                <div>
                    <h2>Student Details</h2>
                    <p>Name: {studentData.data.name}</p>
                    <p>Email: {studentData.data.email}</p>
                    <p>Phone Number: {studentData.data.phone_number}</p>
                    <p>Block: {studentData.data.block}</p>
                    <p>Registration Number: {studentData.data.regNo}</p>
                    {studentData.data.Room && (
                        <div>
                            <h3>Room Details</h3>
                            <p>Room Number: {studentData.data.Room.roomNo}</p>
                            <p>Block: {studentData.data.Room.block}</p>
                        </div>
                    )}
                    {studentData.data.complaint && studentData.data.complaint.length > 0 ? (
                        <div>
                            <h3>Complaints</h3>
                            {studentData.data.complaint.map((complaint) => (
                                <div key={complaint.id}>
                                    <p>Type: {complaint.complaintType}</p>
                                    <p>Date: {complaint.complaintDate}</p>
                                    <p>Description: {complaint.complaintDescription}</p>
                                    <p>Severity: {complaint.complaintSeverity}</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p>No complaints found.</p>
                    )}
                    {studentData.data.leave && studentData.data.leave.length > 0 ? (
                        <div>
                            <h3>Leave Requests</h3>
                            {studentData.data.leave.map((leave) => (
                                <div key={leave.id}>
                                    <p>Type: {leave.leaveType}</p>
                                    <p>Date: {leave.leaveDate}</p>
                                    <p>Time: {leave.leaveTime}</p>
                                    <p>Duration: {leave.LeaveDuration} day(s)</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p>No leave requests found.</p>
                    )}
                </div>
            ) : (
                <p>No data found.</p>
            )}
            <h2>Warden Name</h2>
            {wardenName ? <p>{wardenName}</p> : <p>Loading...</p>}
        </div>
    );
};

export default App;
